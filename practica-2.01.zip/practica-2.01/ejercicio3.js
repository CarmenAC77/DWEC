"use strict";
/**Una función recibe dos números. El primer número muestra cuántos valores se mostrarán y el segundo por el que empieza la serie. Los 
 * siguientes valores se van incrementando en progresión de 2, es decir, el anterior multiplicado por 2.
 * @param {number} cantidad que será la cantidad de valores a mostrar
 * @param {number} valorInicial que será el valor inicial por el que empieza la secuencia
 */
function mostrarDobles(cantidad, valorInicial) {
    let valorActual = valorInicial;
    let resultado = "";
    
    for (let i = 0; i < cantidad; i++){
        resultado += `${valorActual} `; /*importante el espacio para que separe los valores*/
        valorActual *= 2;
    }
    console.log(resultado.trim());
}
mostrarDobles(4,6);
mostrarDobles(3,9);