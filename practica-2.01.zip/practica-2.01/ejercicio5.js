"use strict";
/**Propinas - Consiste en crear calculadoras de propinas y mostrar por pantalla cuadro con factura, propina y total*/
const facturas = [124,48,268];
/**calculadora propina
* @param {number} factura Importe inicial factura
* @returns {number} propina importe de la propina 
*/
function calcularPropina(factura){
    if (factura<50){
        return factura*0.2;
    } else if (factura<= 200){
        return factura*0.15;
    } 
    return factura*0.1;
}
/**Creación array con propinas y factura final
 * @param {number[]} facturasRestaurantes que será un array con las facturas
 */
function mostrarPropinas(facturasRestaurantes){
    const propinas = [];
    const totales = [];
    for (let i = 0; i< facturasRestaurantes.length; i++){
        const propina = calcularPropina(facturasRestaurantes[i]);
        const total = facturasRestaurantes[i] + propina;

        propinas.push(propina);
        totales.push(total);
    }
    console.log(`FACTURA\tPROPINA\tTOTAL`);
    console.log(`--------------------------------`);
    for (let i = 0; i < facturasRestaurantes.length; i++){
        console.log(
            ` ${facturasRestaurantes[i].toFixed(2)}\t${propinas[i].toFixed(2)}\t${totales[i].toFixed(2)}`
        );
    }
}
mostrarPropinas(facturas);