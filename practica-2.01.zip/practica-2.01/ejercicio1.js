"use strict";
/**
 * El programa consiste en comparar los IMC de Marcos y Juar. Si el IMC de Marcos es menor que el de Juan se mostrará el valor:true
 * 1º Necesitamos calcular el índice de masa corporal
 * 2ºComparar ambos índices
 * Definimos las variables a utilizar y las funciones:
 * @param {number} masa de la persona en kilográmos
 * @param {number} altura de la persona en metros
 * @returns {number} IMC (índice masa corporal)
 */
/*Definimos la función que calcula el IMC:*/
function calcularIMC(masa, altura) {
    return masa/(altura*altura);
}
/*Definimos las varables:*/
const masaMarcos = 80;
const alturaMarcos = 1.80;
const masaJuan = 77;
const alturaJuan = 1.80;
const imcMarcos = calcularIMC(masaMarcos, alturaMarcos);
const imcJuan=calcularIMC(masaJuan, alturaJuan);
/*Definimos la comparación del IMC que será true si el IMC de Marcos es menor que el de Juan*/
const comparativa = imcMarcos < imcJuan;
/*salida por consola*/
console.log(`IMC de Marcos: ${imcMarcos.toFixed(2)}`);
console.log(`IMC de Juan: ${imcJuan.toFixed(2)}`);
console.log(`¿Tiene Marcos un IMC menor que el de Juan?: ${comparativa}`
);