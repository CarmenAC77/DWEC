/**Genera una función que imprima por consola las tablas de multiplicar de los números que van 
* desde el indicado como parámetro (entero positivo mayor a dos) hasta dos. Para ello recibe 
* dos parámetros: un número y una función. 
* 1 La función pasada como parámetro será la que calcule la tabla de multiplicar. Habrá 
* que diseñar primero esa función y luego pasarla como parámetro. Esta función recibe 
* un número como parámetro e imprime su tabla de multiplicar (debidamente 
* formateada). 
* Por ejemplo, si se ejecuta tablas(5, multiplicar) imprimirá por consola las tablas del dps. 
* La del tres, la del cuatro y la del cinco, eso sí, debidamente formateadas.  */
"use strict";
/**función multiplicar
 * @param {number} numero será el número que definirá hasta dónde se ha de mostrar las tablas desde 2 hasta ese número
 * @param {function} funcion */

function multiplicar(numero) {
/*    if (!Number.isInteger(numero) || numero < 2) {
        console.error(`Error -Debes introducir un número que sea entero y mayor que 2`)
        return;
    }*/
    console.log("\n=================================");
    console.log(`      TABLA DEL ${numero}`);
    console.log("=================================");
    for (let i = 1; i<=10; i++) {
        console.log(`${numero} x ${i} = ${numero*i}`);
    }
}
/*función para mostrar las tablas*/
function tablas(numero, funcion){
    if (!Number.isInteger(numero) || numero < 2) {
        console.error(`Error -Debes introducir un número que sea entero y mayor que 2`)
        return;
    }
    for (let i = 2; i <= numero; i++) {
        funcion(i);
    }
}
tablas(4, multiplicar);