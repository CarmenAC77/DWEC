"use strict";
/**
 * Muestra por consola la información de cualquier objeto.
 * @param {object} objeto
 */
function imprimirObjeto(objeto) {
    console.log("=================================================");
    console.log("TIPO\t\tPROPIEDAD\t\tVALOR");
    console.log("=================================================");
    for (let propiedad in objeto) {
        const valor = objeto[propiedad];
        // STRING
        if (typeof valor === "string") {
            console.log(
                `string\t\t${propiedad}\t\t${valor}`
            );
        }
        // NUMBER
        else if (typeof valor === "number") {
            console.log(
                `number\t\t${propiedad}\t\t${valor}`
            );
        }
        // ARRAY
        else if (Array.isArray(valor)) {
            console.log(
                `array\t\t${propiedad}\t\t${valor.join(", ")}`
            );
        }
        // FUNCTION
        else if (typeof valor === "function") {
            console.log(
                `function\t${propiedad}\t\t[Método]`
            );
        }
        // OBJECT
        else if (typeof valor === "object") {
            console.log(
                `object\t\t${propiedad}`
            );
            for (let subpropiedad in valor) {
                console.log(
                    `\t\t${subpropiedad}: ${valor[subpropiedad]}`
                );
            }
        }
    }
    console.log("=================================================");
}
//Ejemplo
const coche = {

    marca: "Seat",

    modelo: "León",

    año: 2022,

    colores: [
        "rojo",
        "blanco",
        "negro"
    ],

    propietario: {

        nombre: "Ana",
        edad: 25
    },

    arrancar: function () {

        console.log("Motor en marcha");
    }
};

imprimirObjeto(coche);