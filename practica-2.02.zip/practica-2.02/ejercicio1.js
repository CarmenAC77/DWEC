"use strict";
/**Crea una función que permita sumar todos los números pasados como parámetros. Deberá 
* seguir estas premisas: 
* 1 comprobará si son de tipo numérico antes de realizar la operación, si no lo es, lanzará un 
* mensaje de error por consola y detendrá la ejecución del programa, 
* 2 debe tener como mínimo dos parámetros o no se ejecutará. Debe informar al 
* usuario, 
* 3 la salida debe estar debidamente formateada. 
*/
function sumar() {
    if (arguments.length < 2) {/*valida si hay menos de dos sumandos y si no lo es lanza error*/
        console.error(`Error - Debes introducir al menos dos números para que se pueda sumar`);
        return;
    }
    let suma = 0; /*aquí almacenaré la suma de los argumentos(sumandos)*/
    let lista = []; /*creo este array para ir acumulando los argumentos que cumplen que sean números*/
    for (let i = 0; i < arguments.length; i++) { /*recorro todos los argumentos*/
        if(typeof arguments[i] !== "number") { /*valido que sean números y si no lo son lanzo error*/
            console.error(`Error - El ${arguments[i]} no es un número.`);
        return;
        }
        suma += arguments[i]; /*suma*/
        lista.push(arguments[i]);/*añade en el array el argumento*/
    }
    console.log(`El resultado de la suma de: ${lista.join(" + ")} es ${suma}`);
    console.log(`El resultado de la suma de: ${Array.from(arguments).join(" + ")} es ${suma}`); /*esta versión es para evitar tener que hacer el array lista*/

}
sumar(5, 10);
sumar(2, 3, 4, 5);
sumar(10, "hola", 3);
sumar(23);