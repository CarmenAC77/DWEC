"use strict";
/**Escribe la función calcular() para que maneje tres arrays (no serán pasados como parámetros 
* a esta función sino declarados dentro de ella). Lo que sí se pasará como parámetros serán tres 
* funciones con el siguiente comportamiento: 
* • una para generar un array con números aleatorios comprendidos entre 1 y 100, la 
* cantidad de números generados será pasado como parámetro, 
* • otra que recibe dos arrays como parámetros y genera un array que contenga la suma 
* de las cifras que ocupen posiciones contrarias, es decir, la primera posición del primero 
* sumada a la última posición del segundo (los arrays deben tener la misma longitud), 
* • y la última para imprimir un array por consola debidamente formateado. 
* La ejecución del programa se realizará a través de la función calcular() del siguiente modo: 
*calcular(funcion1, funcion2, funcion3);*/
/**función para generar arrays de números aleatorios
* @param {number} longitud
* @returns {Array}
*/
function generarArray(longitud){
    const array = []; /*inicializamos el array*/

    for (let i = 0; i< longitud; i++){ /*para cada lectura se genera un número aleatorio que se introduce en el array hasta completar la longitud requerida por el parámetro longitud*/
        array.push(Math.floor(Math.random()*100)+1);
    }
    return array;

}
/**función para generar array de posicones opuestas
 * @param {Array} array1
 * @param {Array} array2
 * @returns {Array} devuelve un array que será la suma del primer elemento del array 1 con el último del array 2 y así va sumando 
 */

function sumarVectores(array1, array2){
    if (!Array.isArray(array1) || !Array.isArray(array2)) {/*validar que las entradas sean arrays*/
        console.error(
            `Error - Las entradas han de ser arrays`
        );
        return;
    }
    
    if (array1.length !== array2.length) {/*validar que tengan la misma longitud*/
        console.error(
            `Error - Ambos arrays deben tener la misma longitud.`
        );
        return;
    }
    
    const resultado = []; /*esta será el array resultado*/
    for(let i = 0; i < array1.length; i++){
        resultado.push(
            array1[i] + array2[array2.length -1 -i]
        );
    }
    return resultado;
}
/**función mostrar array resultado
*@param {Array} array 
*/
function imprimirArray(array){
    console.log(`[ ${array.join(" , ")} ]`);
}

/**función principal que une las tres anteriores
 * @param {function} generar
 * @param {function} sumar
 * @param {function} imprimir
 */
function calcular(generar, sumar, imprimir){

    const array1 = generar(10);//esto es lo mismo que decir generarArray(10)
    const array2 = generar(10);
    const arrayResultado = sumar(array1, array2); //esto es lo mismo que decir sumarVectores(array1,array2)

    console.log("======================================");
    console.log("ARRAY 1");
    imprimir(array1);

    console.log("\nARRAY 2");
    imprimir(array2);

    console.log("\nARRAY RESULTADO");
    imprimir(arrayResultado);
    console.log("======================================");

}
//Llamada a la función principal
calcular(
    generarArray,
    sumarVectores,
    imprimirArray
);