"use strict";
/**
El programa consiste en definir una serie de funciones que consigan:
1.Imprimir una cadena que indique los puntos de un equipo, se le pasará el array y el 
nombre del equipo. 
2.Función calcular la puntuación media de puntos (los puntos se le pasan como 
parámetro), 
3.Otra para mostrar qué equipo tiene mejor media de puntuación e imprime el ganador 
en la consola. Incluye en la salida también la media de puntuación del equipo. No 
olvides tener en cuenta el posible caso de un empate (misma puntuación media). Como 
parámetros se entregan los puntos y nombre de cada equipo. 
Se usarán arrays para almacenar los puntos de cada equipo
*/
/*Arrays*/
const puntosJuan = [89,120,103];
const puntosMiguel = [116,94,123];
const puntosMaria = [97,134,105];
const puntosAlberto =[134,97,105];
/**1.Función para mostrar los puntos de los equipos
* @param {number[]} puntos Puntuaciones del equipo
* @param {string} nombre Nombre del equipo 
*/
function mostrarPuntos(puntos, nombre) {
    console.log(`Los puntos del equipo de ${nombre} son: ${puntos.join( " - ")}`);
}
/**2.Calcular la media de puntos de un equipo
 * @param {number[]} puntos Puntuaciones del equipo
 * @returns {number} Media de puntos
 * puntos es un array, entonces se lee todos los puntos de dentro del array para crear el total con el for, que va desde 0 hasta la longitud del array que
 * indica cuántos elementos tiene. La media se obtiene dividiendo la suma de los puntos entre el número de sumandos.
 */
function calcularMedia(puntos) {
    let suma = 0;
    for (let i = 0; i< puntos.length; i++) {
        suma += puntos[i];
    }
    return suma / puntos.length;
}
/**Mostrar la puntuación media de cada equipo
* @param {number[]} puntos Puntuaciones del equipo
* @param {string} nombre Nombre del equipo 
 */
function mostrarMedia(puntos, nombre) {
    const media = calcularMedia(puntos);
    console.log(`La puntuación media del equipo de ${nombre} es: ${media.toFixed(2)}`);
}
/**3.Determinar qué equip tiene mayor puntuación media
 * @param {object[]} equipos Equipos que participan en la comparación
 */
function mostrarGanador(equipos) {
    let mejorMedia = calcularMedia(equipos[0].puntos);
    let ganadores = [equipos[0].nombre];
    for (let i = 1; i < equipos.length; i++){
        const mediaActual = calcularMedia(equipos[i].puntos);
        if (mediaActual > mejorMedia){
        mejorMedia = mediaActual;    
        ganadores = [equipos[i].nombre];
        } else if (mediaActual === mejorMedia){
            ganadores.push(equipos[i].nombre);
        }
    }
    if (ganadores.length === 1) {
        console.log(`El equipo ganador es: ${ganadores[0]} y la puntuación media es: ${mejorMedia.toFixed(2)}`);
    } else {
        console.log(`Hay un empate entre los equipos de ${ganadores.join(" y ")} con una puntuación media de: ${mejorMedia.toFixed(2)}`);
    }
}
mostrarPuntos(puntosJuan, "Juan");
mostrarMedia(puntosJuan, "Juan");
mostrarPuntos(puntosMiguel, "Miguel");
mostrarMedia(puntosMiguel, "Miguel");
mostrarPuntos(puntosMaria, "Maria");
mostrarMedia(puntosMaria, "Maria");
mostrarPuntos(puntosAlberto, "Alberto");
mostrarMedia(puntosAlberto, "Alberto");

/*Construcción de array equipos para que permita realizar el ejercicio con varios equipos, porque leerá todo el array que lo contenga*/
const equipos = [
    {
    nombre: "Juan",
    puntos: puntosJuan,
    },
    {
    nombre: "Miguel",
    puntos: puntosMiguel,
    },
    {
    nombre: "Maria",
    puntos: puntosMaria,
    },
    {
    nombre: "Alberto",
    puntos: puntosAlberto,
    }
]

mostrarGanador(equipos);