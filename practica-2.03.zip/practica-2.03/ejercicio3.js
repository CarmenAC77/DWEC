"use strict";
/** Crea un objeto denominado discente que tenga las siguientes propiedades: id, nombre, 
apellidos, aficiones (que será un array de string) y notas (que será un objeto con las propiedades 
primera, segunda y tercera con las notas de cada evaluación).  */
/**Definición del objeto discente
 * @type {number} id
 * @type {string} nombre
 * @type {string} apellidos
 * @type {Array<string>} aficiones array de string
 * @type {object} notas :
 *      @type {number} primera eva
 *      @type {number} segunda eva
 *      @type {number} tercera eva
 * 
 */
//constructor

const discente = {
    id: 2,
    nombre: "Ana",
    apellidos: "López Martín",
    aficiones: [
        "pintar",
        "bailar",
        "tocar el piano"
    ],
    notas: {
        primera: 9,
        segunda: 8.5,
        tercera: 9.8
    },
    
    /**
     * Calcula la nota media.
     * @returns {number}
     */
    calcularMedia: function () {
        return (
            this.notas.primera +
            this.notas.segunda +
            this.notas.tercera
        ) / 3;
    },

    /**
     * Muestra las aficiones.
     */
    imprimirAficiones: function () {
        console.log(
            this.aficiones.join(", ")
        );
    },

    /**
     * Muestra un informe completo.
     */
    imprimirInforme: function () {
        console.log("\nInforme completo del discente:\n");
        console.log(`ID: ${this.id}`);
        console.log(
            `Nombre: ${this.nombre} ${this.apellidos}`
        );
        console.log(
            `Aficiones: ${this.aficiones.join(", ")}`
        );
        console.log(
            `Notas: Primera Evaluación: ${this.notas.primera}, ` +
            `Segunda Evaluación: ${this.notas.segunda}, ` +
            `Tercera Evaluación: ${this.notas.tercera}`
        );
        console.log(
            `Nota Media: ${this.calcularMedia().toFixed(2)}`
        );
    }
};
discente.imprimirInforme();