"use strict";
//Partimos del ejercicio 1 y añadimos el mostrar los objetos creando una nueva función
/**Crear una función que simule ser un constructor de objetos tipo curso. Los atributos serían:
 * @param {string} nombre
 * @param {number} año
 * @param {string} descripcion
 * @param {Array} alumnado
 * @returns {Object}
 */
function curso(nombre, año, descripcion, alumnado) {

    return {
        nombre: nombre,
        año: año,
        descripcion: descripcion,
        alumnado: alumnado
    };
}

const cursoDaw = curso(
    "Desarrollo Web",
    2025,
    "Curso de DAW",
    ["Juan", "Pepe", "Ana"]
);

console.log(cursoDaw);

console.log(cursoDaw.nombre);
console.log(cursoDaw.año);
console.log(cursoDaw.descripcion);
console.log(cursoDaw.alumnado);



const cursoDam = curso(
    "Desarrollo Aplicaciones Multiplataforma",
    2025,
    "Curso de DAM",
    ["Alberto", "Felipe", "Lucía", "Rosa"]
);
console.log(cursoDam);

console.log(cursoDam.nombre);
console.log(cursoDam.año);
console.log(cursoDam.descripcion);
console.log(cursoDam.alumnado);

//Ejercicio 2 función para imprimir

function imprimirCurso(curso) {

    console.log("==================================================================");
    console.log("INFORME DEL CURSO");
    console.log("TIPO\t\tNOMBRE\t\tVALOR");
    console.log("==================================================================");

    for (let propiedad in curso) {

        console.log(
                        `${typeof curso[propiedad]}\t\t${propiedad}\t\t${curso[propiedad]}`
        );
    }

    console.log("==================================================================");
}

imprimirCurso(cursoDaw);
imprimirCurso(cursoDam)