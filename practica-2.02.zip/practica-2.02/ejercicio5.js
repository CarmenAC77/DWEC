"use strict";
/**Generar un marco exterior que a su vez contenga otro marco interior. 
 * Crear una función que recibe dos parámetros, uno es el tamaño exterior del marco
 * el otro es el tamaño interior del marco. El exterior hasta el interior se pinta con 
 * el símbolo de # y el del interior con .
 * @param {number} exterior indicará el tamaño del lienzo o marco exterior
 * @param {number} interior indicará el tamaño del marco interior
 */
function dibujarMarco(exterior, interior){
    if (!Number.isInteger(exterior)|| //valida que sea entero
    !Number.isInteger(interior)|| 
    exterior<=interior || //valida que el marco interior no sea mayor al exterior
    (exterior - interior) % 2 !== 0 //para que quede centrado el hueco necesitamos que sea divisible exacto entre 2
    ){
        console.error(`Debes introducir un número entero, el tamaño del marco exterior debe ser mayor que el interior y ha de ser divible entre 2`);
        return;
    } //si no cumple sale el error por consola
    const margen = (exterior - interior) /2; //de esta forma distribuimos y centramos el hueco o interior en el lienzo exterior
    console.log(`Marco exterior ${exterior} * marco interior ${interior} `);

    for ( let fila = 0 ; fila < exterior; fila++){ //para recorrer todas las filas del tamaño del lienzo exterior
        
        let linea = ""; //para dibujar las líneas 
        
        for (let columna = 0; columna <exterior; columna++ ){ //para recorrer todas las columnas del lienzo exterior

            const hueco = //aquí vamos a indicar las condiciones para que sea true y para ello será
                fila >= margen && // que la fila sea mayor al margen pero menor al margen y el interior (pasa al siguiente bloque exterior)
                fila < margen + interior && 
                columna >= margen && //que además la columna sea mayor al margen o igual pero que sea menor a la suma del margen y el interior
                columna < margen + interior;

            linea += hueco ? "." : "#" //ternaria para que pinte . en el hueco si hueco es true y # si es false
        }
        console.log(`${fila+1} ${linea}`);//fila+1 es para numerar las filas
    }

}
dibujarMarco(5,2);
dibujarMarco(8,4);
dibujarMarco(18,6);
