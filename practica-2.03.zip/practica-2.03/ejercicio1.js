"use strict";

/**Crear una función que simule ser un constructor de objetos tipo curso. Los atributos serían:
 * @type {string} nombre
 * @type {number} año
 * @type {string} descripcion
 * @type {Array<string>} alumnado
 * @returns {Object}
 */
function curso(nombre, año, descripcion, alumnado) {

    return {
        nombre: nombre,
        año: año,
        descripcion: descripcion,
        alumnado: alumnado
    };
}

const cursoDaw = curso(
    "Desarrollo Web",
    2025,
    "Curso de DAW",
    ["Juan", "Pepe", "Ana"]
);

console.log(cursoDaw);

console.log(cursoDaw.nombre);
console.log(cursoDaw.año);
console.log(cursoDaw.descripcion);
console.log(cursoDaw.alumnado);



const cursoDam = curso(
    "Desarrollo Aplicaciones Multiplataforma",
    2025,
    "Curso de DAM",
    ["Alberto", "Felipe", "Lucía", "Rosa"]
);
console.log(cursoDam);

console.log(cursoDam.nombre);
console.log(cursoDam.año);
console.log(cursoDam.descripcion);
console.log(cursoDam.alumnado);

