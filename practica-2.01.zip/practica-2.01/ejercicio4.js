/**Facturas, crear una función que recibe 3 parámetros 
 * @param {string} nombreProducto mostrará nombre del producto valor por defecto Producto Genérico
 * @param {number} precio será el precio del producto valor por defecto 100
 * @param {number} impuesto será el impuesto, valor por defecto 21
 * Además se tendrá que validar que los números son válidos con (isNan()) para mostrar un error si no lo son
 */
function mostrarFactura (
    nombreProducto = "Producto Genérico",
    precio = 100,
    impuesto = 21
) {
    if (isNaN(precio) || isNaN(impuesto)) {
        console.log(`Error. Número(s) no válido(s).`);
        return;
    }
    const precioFinal = precio + (precio*impuesto)/100;
    console.log(`Producto: ${nombreProducto} - Precio: ${precioFinal}`);
}

mostrarFactura();
mostrarFactura("Producto incorrecto", "abc", 21);
mostrarFactura("Pelota", 50, 21);
mostrarFactura("TV FHD", 875, 21);
