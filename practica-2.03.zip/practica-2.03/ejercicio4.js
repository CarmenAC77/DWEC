"use strict";
//Partiendo del ejercicio 1
function curso(nombre, año, descripcion) {
    return {
        nombre: nombre,
        año: año,
        descripcion: descripcion,
        alumnado: [],
        //función matricular
        matricular: function (discente){
            this.alumnado = [
                ...this.alumnado, 
                discente
            ];
        }     
    };
}
const daw = curso(
    "DAW",
    2025,
    "Desarrollo de Aplicaciones Web"
);
const discente1 = {
    id: 1,
    nombre: "Ana",
    apellidos: "López Martín",
    aficiones: [
        "pintar",
        "bailar",
        "tocar el piano"
    ],
    notas: {

        primera: 9,
        segunda: 8.5,
        tercera: 9.8
    }
};
const discente2 = {
    id: 2,
    nombre: "Carlos",
    apellidos: "García Pérez",
    aficiones: [
        "videojuegos",
        "cine",
        "senderismo"
    ],
    notas: {
        primera: 7,
        segunda: 8,
        tercera: 6.5
    }
};
const discente3 = {
    id: 3,
    nombre: "Marta",
    apellidos: "Ruiz Sánchez",
    aficiones: [
        "lectura",
        "fotografía",
        "viajar"
    ],
    notas: {
        primera: 10,
        segunda: 9,
        tercera: 9.5
    }
};
daw.matricular(discente1);
daw.matricular(discente2);
daw.matricular(discente3);
console.log("=====================================");
console.log("INFORME DEL CURSO");
console.log("=====================================");
console.log(`Nombre: ${daw.nombre}`);
console.log(`Año: ${daw.año}`);
console.log(`Descripción: ${daw.descripcion}`);

console.log("\nALUMNADO MATRICULADO");
console.log("=====================================");

for (let alumno of daw.alumnado) {

    console.log(
        `${alumno.id} - ${alumno.nombre} ${alumno.apellidos}`
    );
}