"use strict";

/**
 * Dibuja una cruz hueca. Se recibe como parámetro el lado de un cuadrado y tiene que ser múltiplo de 3. Consiste en dividir el lienzo en tres tercios horizontalmente y otros tres tercios verticalmente.
 * Al tercio superior se le llama bloque superior. Al tercio inferior se le llama bloque inferior. Al tercio central no se le llama y se rellena con .
 * En los tercios superior e inferior, a su vez, se encuentran los tercios verticales. Al tercio primero y último se le rellena con #
 * @param {number} lado
 */
function dibujarCruz(lado) {

    if (!Number.isInteger(lado) || lado % 3 !== 0) { //revisa que sea número entero y además múltipo de 3 si no se cumple lanza mensaje de error
        console.error(
            "Error - El lado debe ser un número entero múltiplo de 3."
        );
        return;
    }
    console.log(`Dibujar Cruz de ${lado}`);
    const tercio = lado / 3; //define cada tercio de la cruz, es decir, cuántos componentes va a tener cada tercio para dibujarla

    for (let fila = 0; fila < lado; fila++) { //recorre toda la longitud de la cruz

        let linea = ""; //para dibujar las líneas

        for (let columna = 0; columna < lado; columna++) { //para ir asignando cada tercio a su bloque

            const bloqueSuperior = //define el bloque superior que se rellenará con # para las filas que estén antes del tercio y además estén entre las columnas anterior y posterior del tercio central
                fila < tercio &&
                (columna < tercio || columna >= 2 * tercio);

            const bloqueInferior = //define el bloque inferior que se rellenará con # para las filas que estén después del segundo tercio y además estén entre las columnas anterior y posterior del tercio central
                fila >= 2 * tercio &&
                (columna < tercio || columna >= 2 * tercio);

            linea += (bloqueSuperior || bloqueInferior) //pinta con un # lo que está en el bloque superior o inferior, el resto hasta la longitud lo pinta con .
                ? "#"
                : ".";
        }

        console.log(`${fila+1} ${linea}`);
    }
}

dibujarCruz(21);
dibujarCruz(9);
dibujarCruz(25);